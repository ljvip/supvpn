-- MySQL dump 10.13  Distrib 5.7.44, for Linux (x86_64)
--
-- Host: localhost    Database: sup_vpn
-- ------------------------------------------------------
-- Server version	5.7.44-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admin_extension_histories`
--

DROP TABLE IF EXISTS `admin_extension_histories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_extension_histories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` tinyint(4) NOT NULL DEFAULT '1',
  `version` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `detail` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `admin_extension_histories_name_index` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_extension_histories`
--

LOCK TABLES `admin_extension_histories` WRITE;
/*!40000 ALTER TABLE `admin_extension_histories` DISABLE KEYS */;
/*!40000 ALTER TABLE `admin_extension_histories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_extensions`
--

DROP TABLE IF EXISTS `admin_extensions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_extensions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `version` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `is_enabled` tinyint(4) NOT NULL DEFAULT '0',
  `options` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `admin_extensions_name_unique` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_extensions`
--

LOCK TABLES `admin_extensions` WRITE;
/*!40000 ALTER TABLE `admin_extensions` DISABLE KEYS */;
/*!40000 ALTER TABLE `admin_extensions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_menu`
--

DROP TABLE IF EXISTS `admin_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_menu` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` bigint(20) NOT NULL DEFAULT '0',
  `order` int(11) NOT NULL DEFAULT '0',
  `title` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `icon` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `uri` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `extension` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `show` tinyint(4) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_menu`
--

LOCK TABLES `admin_menu` WRITE;
/*!40000 ALTER TABLE `admin_menu` DISABLE KEYS */;
INSERT INTO `admin_menu` VALUES (1,0,1,'Index','feather icon-bar-chart-2','/','',1,'2023-11-29 00:43:56',NULL),(2,0,2,'Admin','feather icon-settings','','',1,'2023-11-29 00:43:56',NULL),(3,2,3,'Users','','auth/users','',1,'2023-11-29 00:43:56',NULL),(4,2,4,'Roles','','auth/roles','',1,'2023-11-29 00:43:56',NULL),(5,2,5,'Permission','','auth/permissions','',1,'2023-11-29 00:43:56',NULL),(6,2,6,'Menu','','auth/menu','',1,'2023-11-29 00:43:56',NULL),(7,2,7,'Extensions','','auth/extensions','',1,'2023-11-29 00:43:56',NULL),(11,0,11,'设备管理',NULL,NULL,'',1,'2023-11-30 13:21:54','2023-11-30 13:21:54'),(12,11,12,'设备列表',NULL,'/user_cc','',1,'2023-11-30 13:24:28','2023-11-30 13:24:28'),(13,15,13,'网站列表',NULL,'/user_url','',1,'2023-11-30 13:25:25','2023-12-11 09:43:16'),(14,15,14,'代理列表',NULL,'/user_ssr','',1,'2023-11-30 13:35:47','2023-12-11 09:43:21'),(15,0,15,'平台管理',NULL,NULL,'',1,'2023-12-10 10:28:35','2023-12-10 10:28:35'),(16,15,16,'平台列表',NULL,'/platform','',1,'2023-12-10 10:28:56','2023-12-10 10:28:56');
/*!40000 ALTER TABLE `admin_menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_permission_menu`
--

DROP TABLE IF EXISTS `admin_permission_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_permission_menu` (
  `permission_id` bigint(20) NOT NULL,
  `menu_id` bigint(20) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  UNIQUE KEY `admin_permission_menu_permission_id_menu_id_unique` (`permission_id`,`menu_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_permission_menu`
--

LOCK TABLES `admin_permission_menu` WRITE;
/*!40000 ALTER TABLE `admin_permission_menu` DISABLE KEYS */;
/*!40000 ALTER TABLE `admin_permission_menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_permissions`
--

DROP TABLE IF EXISTS `admin_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_permissions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `http_method` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `http_path` text COLLATE utf8mb4_unicode_ci,
  `order` int(11) NOT NULL DEFAULT '0',
  `parent_id` bigint(20) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `admin_permissions_slug_unique` (`slug`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_permissions`
--

LOCK TABLES `admin_permissions` WRITE;
/*!40000 ALTER TABLE `admin_permissions` DISABLE KEYS */;
INSERT INTO `admin_permissions` VALUES (1,'Auth management','auth-management','','',1,0,'2023-11-29 00:43:56',NULL),(2,'Users','users','','/auth/users*',2,1,'2023-11-29 00:43:56',NULL),(3,'Roles','roles','','/auth/roles*',3,1,'2023-11-29 00:43:56',NULL),(4,'Permissions','permissions','','/auth/permissions*',4,1,'2023-11-29 00:43:56',NULL),(5,'Menu','menu','','/auth/menu*',5,1,'2023-11-29 00:43:56',NULL),(6,'Extension','extension','','/auth/extensions*',6,1,'2023-11-29 00:43:56',NULL);
/*!40000 ALTER TABLE `admin_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_role_menu`
--

DROP TABLE IF EXISTS `admin_role_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_role_menu` (
  `role_id` bigint(20) NOT NULL,
  `menu_id` bigint(20) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  UNIQUE KEY `admin_role_menu_role_id_menu_id_unique` (`role_id`,`menu_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_role_menu`
--

LOCK TABLES `admin_role_menu` WRITE;
/*!40000 ALTER TABLE `admin_role_menu` DISABLE KEYS */;
/*!40000 ALTER TABLE `admin_role_menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_role_permissions`
--

DROP TABLE IF EXISTS `admin_role_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_role_permissions` (
  `role_id` bigint(20) NOT NULL,
  `permission_id` bigint(20) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  UNIQUE KEY `admin_role_permissions_role_id_permission_id_unique` (`role_id`,`permission_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_role_permissions`
--

LOCK TABLES `admin_role_permissions` WRITE;
/*!40000 ALTER TABLE `admin_role_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `admin_role_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_role_users`
--

DROP TABLE IF EXISTS `admin_role_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_role_users` (
  `role_id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  UNIQUE KEY `admin_role_users_role_id_user_id_unique` (`role_id`,`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_role_users`
--

LOCK TABLES `admin_role_users` WRITE;
/*!40000 ALTER TABLE `admin_role_users` DISABLE KEYS */;
INSERT INTO `admin_role_users` VALUES (1,1,'2023-11-29 00:43:57','2023-11-29 00:43:57');
/*!40000 ALTER TABLE `admin_role_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_roles`
--

DROP TABLE IF EXISTS `admin_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_roles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `admin_roles_slug_unique` (`slug`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_roles`
--

LOCK TABLES `admin_roles` WRITE;
/*!40000 ALTER TABLE `admin_roles` DISABLE KEYS */;
INSERT INTO `admin_roles` VALUES (1,'Administrator','administrator','2023-11-29 00:43:56','2023-11-29 00:43:57');
/*!40000 ALTER TABLE `admin_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_settings`
--

DROP TABLE IF EXISTS `admin_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_settings` (
  `slug` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`slug`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_settings`
--

LOCK TABLES `admin_settings` WRITE;
/*!40000 ALTER TABLE `admin_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `admin_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_users`
--

DROP TABLE IF EXISTS `admin_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(80) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `avatar` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `admin_users_username_unique` (`username`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_users`
--

LOCK TABLES `admin_users` WRITE;
/*!40000 ALTER TABLE `admin_users` DISABLE KEYS */;
INSERT INTO `admin_users` VALUES (1,'admin','$2y$10$yVE3M1/EkjJ9tTyal83RmecgwsbvDesGEGkDiQKv6FQQajvoJ588G','Administrator',NULL,'lVYE91kNFiDb5UrsgCLhYu6vTP0Gh3RJSLLkDQNZP1c3WYy3StJ3tangCQt9','2023-11-29 00:43:56','2023-11-29 00:43:57');
/*!40000 ALTER TABLE `admin_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2014_10_12_000000_create_users_table',1),(2,'2014_10_12_100000_create_password_resets_table',1),(3,'2016_01_04_173148_create_admin_tables',1),(4,'2019_08_19_000000_create_failed_jobs_table',1),(5,'2019_12_14_000001_create_personal_access_tokens_table',1),(6,'2020_09_07_090635_create_admin_settings_table',1),(7,'2020_09_22_015815_create_admin_extensions_table',1),(8,'2020_11_01_083237_update_admin_menu_table',1),(9,'2023_11_30_153741_create_websites_table',2),(10,'2023_11_30_154034_create_ssr_table',3),(11,'2023_11_30_211809_create_user_url_table',4),(12,'2023_11_30_211854_create_user_ssr_table',5),(13,'2023_11_30_212014_create_user_cc_table',6),(14,'2023_12_10_182814_create_platform_table',7);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) unsigned NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personal_access_tokens`
--

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `platform`
--

DROP TABLE IF EXISTS `platform`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `platform` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `app_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'app平台名称',
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '状态',
  `ssrs` mediumtext COLLATE utf8mb4_unicode_ci COMMENT 'ssr数据',
  `urls` mediumtext COLLATE utf8mb4_unicode_ci COMMENT '网站地址数据',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `platform`
--

LOCK TABLES `platform` WRITE;
/*!40000 ALTER TABLE `platform` DISABLE KEYS */;
INSERT INTO `platform` VALUES (3,'app_138','1',NULL,NULL,'2023-12-13 20:13:56','2023-12-13 20:13:56'),(4,'app_138cc','1',NULL,NULL,'2023-12-13 20:20:17','2023-12-13 20:20:17'),(5,'app_aoliu','1',NULL,NULL,'2023-12-13 20:28:59','2023-12-13 20:28:59'),(6,'app_php','1',NULL,NULL,'2023-12-13 20:44:46','2023-12-13 20:44:46');
/*!40000 ALTER TABLE `platform` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ssr`
--

DROP TABLE IF EXISTS `ssr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ssr` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `ssr` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'ssr地址',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ssr`
--

LOCK TABLES `ssr` WRITE;
/*!40000 ALTER TABLE `ssr` DISABLE KEYS */;
INSERT INTO `ssr` VALUES (1,'ssr://YmlnLXVzZXJzLmMuY2RuMDEudG9tYXRvb28ueHl6Ojg2Nzk6YXV0aF9hZXMxMjhfbWQ1OmFlcy0yNTYtY2ZiOnBsYWluOmRHOTFhaU52YTJWeU13Lz9yZW1hcmtzPWRpNHpJRUpIVUh6a3VJcm10YmNnNG9DNklPbW1tZWE0cnlBMSZwcm90b3BhcmFtPU5UTTFOemc2TjFKMVYyeEYmb2Jmc3BhcmFtPU1qSTBZVFExTXpVM09DNWpiRzkxWkdaeWIyNTBMbU52YlN4amJHOTFaR1pzWVhKbExtTnZiU3hwZEhWdVpYTXVZWEJ3YkdVdVkyOXRMSGQzZHk1cFkyeHZkV1F1WTI5dExHRnFZWGd1YldsamNtOXpiMlowTG1OdmJTeGhjSEJ6TG1Ka2FXMW5MbU52YlN4M2QzY3VZbWx1Wnk1amIyMA','2023-11-30 09:38:21','2023-11-30 09:38:21'),(2,'ssr://MTAzLjQzLjE5MS4xMDE6NTI1NDpvcmlnaW46YWVzLTEyOC1jdHI6cGxhaW46ZW05dVozZDEvP29iZnNwYXJhbT1NakkwWVRRMU16VTNPQzVqYkc5MVpHWnliMjUwTG1OdmJTeGpiRzkxWkdac1lYSmxMbU52YlN4cGRIVnVaWE11WVhCd2JHVXVZMjl0TEhkM2R5NXBZMnh2ZFdRdVkyOXRMR0ZxWVhndWJXbGpjbTl6YjJaMExtTnZiU3hoY0hCekxtSmthVzFuTG1OdmJTeDNkM2N1WW1sdVp5NWpiMjAmcmVtYXJrcz1NVEF4','2023-11-30 10:07:27','2023-11-30 10:07:27');
/*!40000 ALTER TABLE `ssr` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_cc`
--

DROP TABLE IF EXISTS `user_cc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_cc` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `device_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '设备号码',
  `app_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `times` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '登录次数',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_cc`
--

LOCK TABLES `user_cc` WRITE;
/*!40000 ALTER TABLE `user_cc` DISABLE KEYS */;
INSERT INTO `user_cc` VALUES (11,'4161e8873e80e6cd','138cc资讯网','6','2024-01-12 15:22:42','2024-02-14 21:00:26'),(12,'ed4a653b6c2eb412','138cc资讯网','34','2024-01-13 01:50:50','2024-02-19 02:35:33'),(10,'5994eb7521ddc41e','138cc资讯网','34','2024-01-12 15:22:34','2024-02-19 01:59:43'),(13,'e641547871d1965c','138cc资讯网','28','2024-01-13 02:42:50','2024-02-18 02:33:37'),(14,'c569b7072bd0e1d6','138cc资讯网','8','2024-01-13 03:31:08','2024-01-19 02:00:34'),(15,'2dc049ebd95364b3','138开奖网','6','2024-01-13 17:17:49','2024-02-13 15:03:26'),(16,'2dc049ebd95364b3','138开奖网','1','2024-01-13 17:17:49','2024-01-13 17:17:49'),(17,'7431c2fb9e8ac1b7','138cc资讯网','25','2024-01-13 23:07:35','2024-01-30 19:26:05'),(18,'dc31804e78bd3eb1','138cc资讯网','15','2024-01-14 00:23:41','2024-01-30 01:54:21'),(19,'799739d7d59b7c96','138cc资讯网','4','2024-01-15 16:41:59','2024-01-15 16:43:26'),(20,'44f1faebada1dcf9','138cc资讯网','39','2024-01-15 16:45:36','2024-02-19 06:28:19'),(21,'b391c2410be93278','138cc资讯网','8','2024-01-16 03:53:49','2024-01-22 21:22:18'),(22,'10299b48dd2257df','138cc资讯网','1','2024-01-19 15:22:10','2024-01-19 15:22:10'),(23,'10299b48dd2257df','138cc资讯网','1','2024-01-19 15:22:10','2024-01-19 15:22:10'),(24,'7bdd885ea291994a','138cc资讯网','3','2024-01-22 23:12:50','2024-01-24 20:15:01'),(25,'f95ec129d515a8e4','138cc资讯网','16','2024-01-24 04:07:07','2024-02-09 00:01:49'),(26,'dce90a51ddb674f0','138cc资讯网','20','2024-01-27 21:08:54','2024-02-19 03:30:28'),(27,'d2f6954ca8c4c1c2','138cc资讯网','4','2024-02-07 22:20:22','2024-02-07 22:27:52'),(28,'68c9d660a56cb7c4','138cc资讯网','4','2024-02-14 18:47:19','2024-02-14 19:30:09'),(29,'99aabbcf33376cdb','138cc资讯网','2','2024-02-16 02:35:32','2024-02-16 02:35:33');
/*!40000 ALTER TABLE `user_cc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_ssr`
--

DROP TABLE IF EXISTS `user_ssr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_ssr` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `device_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '设备号码',
  `app_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `ssr` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '代理地址',
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '代理名称',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_ssr`
--

LOCK TABLES `user_ssr` WRITE;
/*!40000 ALTER TABLE `user_ssr` DISABLE KEYS */;
INSERT INTO `user_ssr` VALUES (11,'','4','ssr://YmlnLXVzZXJzLmMuY2RuMDEudG9tYXRvb28ueHl6Ojg2Nzk6YXV0aF9hZXMxMjhfbWQ1OmFlcy0yNTYtY2ZiOnBsYWluOmRHOTFhaU52YTJWeU13Lz9yZW1hcmtzPWRpNHpJRUpIVUh6a3VJcm10YmNnNG9DNklPbW1tZWE0cnlBMSZwcm90b3BhcmFtPU5UTTFOemc2TjFKMVYyeEYmb2Jmc3BhcmFtPU1qSTBZVFExTXpVM09DNWpiRzkxWkdaeWIyNTBMbU52YlN4amJHOTFaR1pzWVhKbExtTnZiU3hwZEhWdVpYTXVZWEJ3YkdVdVkyOXRMSGQzZHk1cFkyeHZkV1F1WTI5dExHRnFZWGd1YldsamNtOXpiMlowTG1OdmJTeGhjSEJ6TG1Ka2FXMW5MbU52YlN4M2QzY3VZbWx1Wnk1amIyMA','代理1','2023-12-13 21:01:52','2023-12-13 21:01:52'),(12,'','3','ssr://YmlnLXVzZXJzLmMuY2RuMDEudG9tYXRvb28ueHl6Ojg2Nzk6YXV0aF9hZXMxMjhfbWQ1OmFlcy0yNTYtY2ZiOnBsYWluOmRHOTFhaU52YTJWeU13Lz9yZW1hcmtzPWRpNHpJRUpIVUh6a3VJcm10YmNnNG9DNklPbW1tZWE0cnlBMSZwcm90b3BhcmFtPU5UTTFOemc2TjFKMVYyeEYmb2Jmc3BhcmFtPU1qSTBZVFExTXpVM09DNWpiRzkxWkdaeWIyNTBMbU52YlN4amJHOTFaR1pzWVhKbExtTnZiU3hwZEhWdVpYTXVZWEJ3YkdVdVkyOXRMSGQzZHk1cFkyeHZkV1F1WTI5dExHRnFZWGd1YldsamNtOXpiMlowTG1OdmJTeGhjSEJ6TG1Ka2FXMW5MbU52YlN4M2QzY3VZbWx1Wnk1amIyMA','代理1','2023-12-13 21:07:41','2023-12-13 21:07:41'),(13,'','5','ssr://YmlnLXVzZXJzLmMuY2RuMDEudG9tYXRvb28ueHl6Ojg2Nzk6YXV0aF9hZXMxMjhfbWQ1OmFlcy0yNTYtY2ZiOnBsYWluOmRHOTFhaU52YTJWeU13Lz9yZW1hcmtzPWRpNHpJRUpIVUh6a3VJcm10YmNnNG9DNklPbW1tZWE0cnlBMSZwcm90b3BhcmFtPU5UTTFOemc2TjFKMVYyeEYmb2Jmc3BhcmFtPU1qSTBZVFExTXpVM09DNWpiRzkxWkdaeWIyNTBMbU52YlN4amJHOTFaR1pzWVhKbExtTnZiU3hwZEhWdVpYTXVZWEJ3YkdVdVkyOXRMSGQzZHk1cFkyeHZkV1F1WTI5dExHRnFZWGd1YldsamNtOXpiMlowTG1OdmJTeGhjSEJ6TG1Ka2FXMW5MbU52YlN4M2QzY3VZbWx1Wnk1amIyMA','代理1','2023-12-13 21:09:20','2023-12-13 21:09:20'),(14,'','6','ssr://YmlnLXVzZXJzLmMuY2RuMDEudG9tYXRvb28ueHl6Ojg2Nzk6YXV0aF9hZXMxMjhfbWQ1OmFlcy0yNTYtY2ZiOnBsYWluOmRHOTFhaU52YTJWeU13Lz9yZW1hcmtzPWRpNHpJRUpIVUh6a3VJcm10YmNnNG9DNklPbW1tZWE0cnlBMSZwcm90b3BhcmFtPU5UTTFOemc2TjFKMVYyeEYmb2Jmc3BhcmFtPU1qSTBZVFExTXpVM09DNWpiRzkxWkdaeWIyNTBMbU52YlN4amJHOTFaR1pzWVhKbExtTnZiU3hwZEhWdVpYTXVZWEJ3YkdVdVkyOXRMSGQzZHk1cFkyeHZkV1F1WTI5dExHRnFZWGd1YldsamNtOXpiMlowTG1OdmJTeGhjSEJ6TG1Ka2FXMW5MbU52YlN4M2QzY3VZbWx1Wnk1amIyMA','代理1','2023-12-13 22:16:35','2023-12-13 22:16:35');
/*!40000 ALTER TABLE `user_ssr` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_url`
--

DROP TABLE IF EXISTS `user_url`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_url` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `device_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '设备号码',
  `url` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '网址',
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '网站名称',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `app_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_url`
--

LOCK TABLES `user_url` WRITE;
/*!40000 ALTER TABLE `user_url` DISABLE KEYS */;
INSERT INTO `user_url` VALUES (13,'','https://www.google.com.hk','谷歌','2023-12-11 10:13:57','2023-12-11 10:13:57','1'),(14,'','https://33896661-hn.for6bong.com','PHP-代理','2023-12-11 11:56:55','2023-12-11 22:40:49','1'),(12,'','https://1388100.com','138','2023-12-11 10:13:57','2023-12-11 22:38:42','1'),(15,'','https://33896671-hn.for6bong.com','PHP-会员','2023-12-11 20:31:22','2023-12-11 22:42:39','1'),(16,'','https://12649a.cc','奥六','2023-12-11 22:47:32','2023-12-11 22:47:32','1'),(18,'','https://138cc.co','138cc','2023-12-13 19:29:23','2023-12-13 19:29:23','1'),(19,'','https://138cc.co','138cc资讯网','2023-12-13 21:01:52','2023-12-13 21:01:52','4'),(20,'','https://1388100.com','138开奖网','2023-12-13 21:07:41','2023-12-13 21:07:41','3'),(21,'','https://12649a.cc','奥六资料网','2023-12-13 21:09:20','2023-12-13 21:09:20','5'),(22,'','https://338910.app','PHP','2023-12-13 22:16:35','2023-12-14 07:23:08','6'),(24,'','https://138cc.co','138cc','2023-12-14 07:26:43','2023-12-14 07:26:43','6'),(25,'','https://google.com','google','2023-12-14 07:51:37','2023-12-14 07:51:37','6');
/*!40000 ALTER TABLE `user_url` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `websites`
--

DROP TABLE IF EXISTS `websites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `websites` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `host` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '网站地址（https）',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `websites`
--

LOCK TABLES `websites` WRITE;
/*!40000 ALTER TABLE `websites` DISABLE KEYS */;
INSERT INTO `websites` VALUES (1,'https://www.baidu.com','2023-11-30 08:30:15','2023-11-30 08:30:15'),(2,'https://www.google.com.hk','2023-11-30 08:30:33','2023-11-30 08:30:33');
/*!40000 ALTER TABLE `websites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'sup_vpn'
--

--
-- Dumping routines for database 'sup_vpn'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-02-18 23:53:34
